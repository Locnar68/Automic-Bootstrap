# automic_bootstrap/components/ae_lite.py
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path, PurePosixPath as P
from typing import Optional

# Reuse your remote facade (same style as awi.py)
from automic_bootstrap.remote import SSHClient, run, sudo, put_text

log = logging.getLogger(__name__)

@dataclass
class AELiteConfig:
    # Target AE host
    host: str
    ssh_user: str = "ec2-user"
    key_path: str = "~/.ssh/automic-key.pem"

    # AE filesystem layout on the AE host
    ae_home: str = "/opt/automic/AutomationEngine"

    # Where to fetch AE media from on the DB host
    db_host: Optional[str] = None
    db_media_path: str = "/opt/automic/install/Automation.Platform/AutomationEngine"

    # DB connectivity (for ini line etc.)
    db_port: int = 5432
    db_name: str = "AEDB"

    # JDBC detection/copy
    jdbc_glob: str = "postgresql-*.jar"

    # Runtime knobs some helpers expect
    java_bin: str = "/usr/bin/java"
    jcp_port: int = 2217
# ---------------- helpers ----------------

def _file_exists(ssh: SSHClient, path: str) -> bool:
    return run(ssh, f"test -s {path}", check=False).rc == 0

def _dir_exists(ssh: SSHClient, path: str) -> bool:
    return run(ssh, f"test -d {path}", check=False).rc == 0

def _read_local(path: str) -> str:
    with open(os.path.expanduser(path), "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _ensure_dirs(ssh: SSHClient, *dirs: str) -> None:
    sudo(ssh, "mkdir -p " + " ".join(dirs))
    sudo(ssh, f"chown -R {ssh.user}:{ssh.user} " + " ".join(dirs))

def _ensure_java(ssh: SSHClient, java_bin: str) -> None:
    if run(ssh, f"{java_bin} -version", check=False).rc != 0:
        # Try 17 first, then 11
        run(ssh, "sudo -n yum -y install java-17-openjdk || sudo -n dnf -y install java-17-openjdk", check=False)
        run(ssh, "sudo -n yum -y install java-11-openjdk || sudo -n dnf -y install java-11-openjdk", check=False)

def _pull_ae_from_db_to_ae(ae: SSHClient, cfg: AELiteConfig) -> None:
    """
    Copy AutomationEngine from DB host → AE host using the same PEM:
      - upload PEM as temp to AE
      - scp -r from DB:db_media_path to ae_home's parent
    """
    temp_pem = P(f"/home/{ae.user}/.ssh/automic-tmp.pem")
    pem_txt = _read_local(cfg.key_path)

    run(ae, f"mkdir -p /home/{ae.user}/.ssh && chmod 700 /home/{ae.user}/.ssh")
    put_text(ae, pem_txt, str(temp_pem), mode=0o600)

    try:
        parent = str(P(cfg.ae_home).parent)  # /opt/automic
        _ensure_dirs(ae, parent)

        scp_cmd = (
            f"scp -i {temp_pem} -o StrictHostKeyChecking=no -r "
            f"{cfg.ssh_user}@{cfg.db_host}:{cfg.db_media_path} {parent}/"
        )
        rc = run(ae, scp_cmd, check=False).rc
        if rc != 0:
            # retry once with permissive ssh config
            run(ae, f"printf 'Host *\\n\\tStrictHostKeyChecking no\\n' >> /home/{ae.user}/.ssh/config", check=False)
            rc2 = run(ae, scp_cmd, check=False).rc
            if rc2 != 0:
                raise RuntimeError(
                    f"scp AE media failed from {cfg.db_host}:{cfg.db_media_path} → {parent} (rc={rc}, rc2={rc2})"
                )

        # Normalize nested copy (…/AutomationEngine/AutomationEngine)
        if not _dir_exists(ae, cfg.ae_home) and _dir_exists(ae, f"{cfg.ae_home}/AutomationEngine"):
            run(ae, f"mv {cfg.ae_home}/AutomationEngine {cfg.ae_home}", check=False)

        sudo(ae, f"chown -R {ae.user}:{ae.user} {parent}")
    finally:
        run(ae, f"shred -u {temp_pem}", check=False)

def _ensure_ae_present(ae: "SSHClient", cfg: "AELiteConfig") -> None:
    """
    Ensure AutomationEngine files exist under cfg.ae_home.

    Strategy:
      1) If binaries already present, return.
      2) Try to copy AE from the DB host (several candidate source paths).
         - Upload local PEM to AE host temporarily for scp.
         - Copy into the AE parent dir so /AutomationEngine lands correctly.
         - Normalize if a nested AutomationEngine/AutomationEngine occurs.
      3) If still not present, log a warning and exit (non-fatal); AE media may
         not be in the bundle. JDBC/ini can still be set by other steps.
    """
    # Quick presence check
    def _have_engine() -> bool:
        wp_cp = run(
            ae,
            f'bash -lc "ls -1 {cfg.ae_home}/bin 2>/dev/null | egrep \'ucsrv(wp|cp)\'"',
            check=False,
        ).rc == 0
        jp = run(ae, f"test -s {cfg.ae_home}/bin/ucsrvjp.jar", check=False).rc == 0
        return wp_cp or jp

    if _have_engine():
        return

    if not getattr(cfg, "db_host", None):
        log.warning("AE media not present locally and no db_host specified; skipping media copy.")
        return

    # Prepare destination and ownership
    ae_parent = str(P(cfg.ae_home).parent)  # e.g., /opt/automic
    sudo(ae, f"mkdir -p {cfg.ae_home}")
    sudo(ae, f"chown -R {ae.user}:{ae.user} {ae_parent}")

    # Upload PEM so the AE host can scp from the DB host
    pem_remote = f"/home/{ae.user}/.ssh/automic.pem"
    try:
        run(ae, f"mkdir -p /home/{ae.user}/.ssh && chmod 700 /home/{ae.user}/.ssh", check=False)
        pem_text = Path(cfg.key_path).read_text(encoding="utf-8")
        put_text(ae, pem_text, pem_remote, mode=0o600)

        # Candidate source paths on the DB host (first that works wins)
        candidates = [
            cfg.db_media_path,  # caller's hint, default: /opt/automic/install/Automation.Platform/AutomationEngine
            "/opt/automic/install/AutomationEngine",
            "/opt/automic/AutomationEngine",
            "/opt/automic/install/Automation.Platform/automationengine",
            "/opt/automic/install/Automation.Platform/Automationengine",
        ]
        # Dedup while preserving order
        seen = set()
        src_candidates = [p for p in candidates if not (p in seen or seen.add(p))]

        copied = False
        for src in src_candidates:
            # Pull the whole directory into the parent so it lands as .../AutomationEngine
            scp_cmd = (
                f"scp -i {pem_remote} -o StrictHostKeyChecking=no -r "
                f"{cfg.ssh_user}@{cfg.db_host}:{src} {ae_parent}/"
            )
            rc = run(ae, scp_cmd, check=False).rc
            if rc == 0:
                # Normalize double-nesting like /AutomationEngine/AutomationEngine/*
                run(
                    ae,
                    f"bash -lc \"test -d {cfg.ae_home}/AutomationEngine && "
                    f"mv {cfg.ae_home}/AutomationEngine/* {cfg.ae_home}/ && rmdir {cfg.ae_home}/AutomationEngine || true\"",
                    check=False,
                )
                sudo(ae, f"chown -R {ae.user}:{ae.user} {ae_parent}")
                if _have_engine():
                    copied = True
                    log.info("Copied AutomationEngine from DB host path: %s", src)
                    break
                else:
                    log.debug("Copy from %s completed but AE binaries not found; trying next candidate.", src)
            else:
                log.debug("Copy from %s failed with rc=%s; trying next candidate.", src, rc)

        if not copied and not _have_engine():
            log.warning(
                "AutomationEngine binaries not found under %s after copy attempts. "
                "Proceeding without Engine media; you can upload it later.",
                cfg.ae_home,
            )
            return

    finally:
        # Clean up PEM quietly
        run(ae, f"shred -u {pem_remote}", check=False)

def _ensure_jdbc(ae: SSHClient, cfg: AELiteConfig) -> None:
    # Already there?
    have = run(
        ae,
        f'bash -lc "ls -1 {cfg.ae_home}/bin/lib/{cfg.jdbc_glob} 2>/dev/null | head -n1"',
        check=False,
    ).out.strip()
    if have:
        return

    # Try to pull from DB host media (upload PEM temporarily to AE)
    try:
        pem_text = Path(cfg.key_path).read_text(encoding="utf-8")
        pem_remote = f"/home/{ae.user}/.ssh/automic.pem"
        run(ae, f"mkdir -p /home/{ae.user}/.ssh && chmod 700 /home/{ae.user}/.ssh", check=False)
        put_text(ae, pem_text, pem_remote, mode=0o600)

        scp_cmd = (
            f"scp -i {pem_remote} -o StrictHostKeyChecking=no "
            f"{cfg.ssh_user}@{cfg.db_host}:{cfg.db_media_path}/bin/lib/{cfg.jdbc_glob} "
            f"{cfg.ae_home}/bin/lib/ || true"
        )
        sudo(ae, f"mkdir -p {cfg.ae_home}/bin/lib")
        run(ae, scp_cmd, check=False)
    finally:
        run(ae, f"shred -u {pem_remote}", check=False)

    # If still missing, try OS package (Amazon Linux/RHEL families)
    have = run(
        ae,
        f'bash -lc "ls -1 {cfg.ae_home}/bin/lib/{cfg.jdbc_glob} 2>/dev/null | head -n1"',
        check=False,
    ).out.strip()
    if not have:
        run(ae, "sudo -n yum -y install postgresql-jdbc || sudo -n dnf -y install postgresql-jdbc", check=False)
        # Common locations for the jar
        for cand in [
            "/usr/share/java/postgresql-jdbc.jar",
            "/usr/share/java/postgresql.jar",
            "/usr/share/java/postgresql/postgresql.jar",
        ]:
            if run(ae, f"test -s {cand}", check=False).rc == 0:
                sudo(ae, f"cp -f {cand} {cfg.ae_home}/bin/lib/")
                break

    # Final check
    have = run(
        ae,
        f'bash -lc "ls -1 {cfg.ae_home}/bin/lib/{cfg.jdbc_glob} 2>/dev/null | head -n1"',
        check=False,
    ).out.strip()
    if not have:
        raise RuntimeError("JDBC driver not found; tried DB media and system package.")

def _ensure_connect_string(ae: SSHClient, cfg: AELiteConfig) -> None:
    ini = f"{cfg.ae_home}/bin/ucsrv.ini"
    connect = f"jdbc:postgresql://{cfg.db_host}:{cfg.db_port}/{cfg.db_name}?sslmode=disable"
    # ensure ini exists
    run(ae, f"mkdir -p {cfg.ae_home}/bin && touch {ini}", check=False)
    # set/replace required keys
    sed1 = f"sed -i 's#^sqlDriverConnect=.*#sqlDriverConnect={connect}#' {ini} || true"
    sed2 = "sed -i 's#^sqlDriverClass=.*#sqlDriverClass=org.postgresql.Driver#' {ini} || true".format(ini=ini)
    run(ae, f"grep -q '^sqlDriverConnect=' {ini} || echo sqlDriverConnect={connect} >> {ini}", check=False)
    run(ae, sed1, check=False)
    run(ae, f"grep -q '^sqlDriverClass=' {ini} || echo sqlDriverClass=org.postgresql.Driver >> {ini}", check=False)
    run(ae, sed2, check=False)

def _start_jwp_jcp(ae: SSHClient, cfg: AELiteConfig) -> None:
    """
    Best-effort JWP/JCP start without ServiceManager.
    NOTE: Flags may vary across versions; this is intentionally lenient.
    """
    binp = f"{cfg.ae_home}/bin"
    # normalize perms so ec2-user can write logs in bin
    sudo(ae, f"chown -R {ae.user}:{ae.user} {cfg.ae_home}")
    run(ae, f"chmod -R a+rX {cfg.ae_home}", check=False)

    # resolve JAVA on the host
    # - We avoid assuming {cfg.java_bin} exists, falling back to default java
    start_jwp = (
        "sudo -n bash -lc 'cd {binp}; "
        "JAVA=\"$(command -v {java} || command -v java || echo /usr/bin/java)\"; "
        "/usr/bin/nohup \"$JAVA\" -jar ucsrvjp.jar -jwp > jwp.out 2>&1 &'"
    ).format(binp=binp, java=cfg.java_bin)

    start_jcp = (
        "sudo -n bash -lc 'cd {binp}; "
        "JAVA=\"$(command -v {java} || command -v java || echo /usr/bin/java)\"; "
        "/usr/bin/nohup \"$JAVA\" -jar ucsrvjp.jar -jcp -port {port} > jcp.out 2>&1 &'"
    ).format(binp=binp, java=cfg.java_bin, port=cfg.jcp_port)

    # stop any stragglers
    run(ae, "sudo -n pkill -f 'ucsrvjp.jar' || true", check=False)

    run(ae, start_jwp, check=False)
    run(ae, start_jcp, check=False)

def install_ae_lite(cfg: AELiteConfig) -> None:
    with SSHClient(cfg.host, cfg.ssh_user, cfg.key_path) as ae:
        log.info("== AE-lite on %s ==", cfg.host)
        sudo(ae, f"mkdir -p {cfg.ae_home}/bin/lib")
        sudo(ae, f"chown -R {ae.user}:{ae.user} {cfg.ae_home}")

        # Try to populate AE from DB if missing (function keeps non-fatal if not found)
        _ensure_ae_present(ae, cfg)

        # Always try to ensure JDBC
        _ensure_jdbc(ae, cfg)

        # Minimal (non-TLS) connect string if absent
        ini = f"{cfg.ae_home}/bin/ucsrv.ini"
        sudo(
            ae,
            "bash -lc "
            f"\"test -f {ini} || touch {ini}; "
            f"grep -q '^sqlDriverConnect=' {ini} || "
            f"echo 'sqlDriverConnect=jdbc:postgresql://{cfg.db_host}:5432/{cfg.db_name}?sslmode=disable' >> {ini}\""
        )

        log.info("AE-lite finished (JDBC + ini ensured; Engine media optional).")
