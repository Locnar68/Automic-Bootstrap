# automic_bootstrap/components/awi.py
from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from pathlib import PurePosixPath as P
from typing import Optional
from urllib.parse import urlparse

from automic_bootstrap.remote import SSHClient, run, sudo, put_text, put_file

log = logging.getLogger(__name__)

@dataclass
class AWIConfig:
    # Primary target (AWI host)
    host: str                         # AWI host/IP (SSH)
    ssh_user: str = "ec2-user"
    key_path: str = "~/.ssh/automic-key.pem"

    # Paths & names on AWI host
    awi_root: str = "/opt/automic/WebInterface"
    tls_folder: str = "/opt/automic/tls"
    java_bin: str = "/usr/bin/java"

    # Optional: AE public cert to trust
    ae_cert_local_path: str = ""      # local file (Windows OK) to upload
    ae_cert_remote_name: str = "ae_engine.cer"

    # JCP endpoint (must match AE TLS CN and port)
    jcp_ip_or_cn: str = "kkhan-automic-engine"
    jcp_port: int = 8443

    # System name shown in AWI connection picker
    system_name: str = "AELAB"

    # Health endpoint
    awi_url: str = "http://127.0.0.1:8080/awi/"

    # If media is already on AWI host (preferred fast path)
    awi_media_path: str = "/opt/automic/install/Automation.Platform/WebInterface"

    # Fallback source: pull from DB host if AWI has no media
    db_host: Optional[str] = None             # e.g., "13.217.42.167"
    db_ssh_user: str = "ec2-user"
    db_media_path: str = "/opt/automic/install/Automation.Platform/WebInterface"


# ---------------- internal helpers ----------------

def _port_from_url(url: str, default: int = 8080) -> int:
    o = urlparse(url)
    if o.port:
        return int(o.port)
    # fallbacks for common schemes when port not explicit
    if o.scheme == "https":
        return 443
    if o.scheme == "http":
        # AWI commonly runs on 8080 rather than 80
        return default
    return default

def _wait_for_local_port(ssh: SSHClient, port: int, timeout_s: int = 240) -> None:
    """
    Wait until *any* address is listening on :port (0.0.0.0, 127.0.0.1, or ::).
    """
    deadline = time.time() + timeout_s
    # Match any local bind that ends with ":<port>" (IPv4 or IPv6)
    check = f"ss -ltn | awk '{{print $4}}' | egrep -q ':{port}$'"
    while time.time() < deadline:
        if run(ssh, f"bash -lc \"{check}\"", check=False).rc == 0:
            return
        time.sleep(2)
    raise RuntimeError(f"Port {port} did not open within {timeout_s}s")

def _ensure_dirs(ssh: SSHClient, *dirs: str) -> None:
    sudo(ssh, "mkdir -p " + " ".join(dirs))
    sudo(ssh, f"chown -R {ssh.user}:{ssh.user} " + " ".join(dirs))

def _ensure_java(ssh: SSHClient, java_bin: str) -> None:
    # Prefer Java 17 for newer AWI; fall back to 11 if needed
    if run(ssh, f"{java_bin} -version", check=False).rc != 0:
        # Try 17 first
        if run(ssh, "sudo -n yum -y install java-17-openjdk || sudo -n dnf -y install java-17-openjdk", check=False).rc != 0:
            sudo(ssh, "yum -y install java-11-openjdk || dnf -y install java-11-openjdk")
def _file_exists(ssh: SSHClient, path: str) -> bool:
    return run(ssh, f"test -s {path}", check=False).rc == 0

def _dir_exists(ssh: SSHClient, path: str) -> bool:
    return run(ssh, f"test -d {path}", check=False).rc == 0

def _read_local(path: str) -> str:
    with open(os.path.expanduser(path), "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _pull_webinterface_from_db_to_awi(awi: SSHClient, cfg: AWIConfig) -> None:
    """
    Copy the WebInterface directory from DB host to AWI host by:
      1) uploading our local PEM to AWI host (temp)
      2) running scp on the AWI host to pull from DB host
      3) deleting the temp PEM
    """
    if not cfg.db_host:
        raise RuntimeError(
            "AWI media missing locally and no db_host configured to pull from. "
            "Set AWIConfig.db_host to your DB server IP."
        )

    temp_pem = P(f"/home/{awi.user}/.ssh/automic-tmp.pem")
    pem_txt = _read_local(cfg.key_path)
    # ensure .ssh exists and put the pem with strict perms
    run(awi, f"mkdir -p /home/{awi.user}/.ssh && chmod 700 /home/{awi.user}/.ssh")
    put_text(awi, pem_txt, str(temp_pem), mode=0o600)

    try:
        awi_parent = str(P(cfg.awi_root).parent)  # e.g., /opt/automic
        _ensure_dirs(awi, awi_parent)

        scp_cmd = (
            f"scp -i {temp_pem} -o StrictHostKeyChecking=no -r "
            f"{cfg.db_ssh_user}@{cfg.db_host}:{cfg.db_media_path} {awi_parent}/"
        )
        rc = run(awi, scp_cmd, check=False).rc
        if rc != 0:
            # retry once with a permissive ssh config
            run(awi, f"printf 'Host *\\n\tStrictHostKeyChecking no\\n' >> /home/{awi.user}/.ssh/config", check=False)
            rc2 = run(awi, scp_cmd, check=False).rc
            if rc2 != 0:
                raise RuntimeError(
                    f"Failed to scp WebInterface from {cfg.db_host}:{cfg.db_media_path} to {awi_parent} "
                    f"(rc={rc}, rc2={rc2}). Ensure AWI can SSH to DB using the supplied PEM."
                )

        # Normalize possible nested copy (…/WebInterface/WebInterface)
        if not _file_exists(awi, f"{cfg.awi_root}/aa-webui-launcher.jar"):
            run(awi, f"test -s {cfg.awi_root}/WebInterface/aa-webui-launcher.jar && "
                     f"mv {cfg.awi_root}/WebInterface/* {cfg.awi_root}/ || true", check=False)

        if not _file_exists(awi, f"{cfg.awi_root}/aa-webui-launcher.jar"):
            raise RuntimeError("After scp, aa-webui-launcher.jar still not present under AWI root.")

        sudo(awi, f"chown -R {awi.user}:{awi.user} {P(cfg.awi_root).parent}")
        run(awi, f"chmod 644 {cfg.awi_root}/aa-webui-launcher.jar", check=False)

    finally:
        run(awi, f"shred -u {temp_pem}", check=False)

def _ensure_webinterface_present(ssh: SSHClient, cfg: AWIConfig) -> None:
    """
    Ensure {awi_root} exists and contains aa-webui-launcher.jar.
    Order of attempts:
      1) use local AWI media path on AWI host if present
      2) scp from DB host using the same PEM (uploaded temporarily)
    """
    _ensure_dirs(ssh, cfg.awi_root, cfg.tls_folder)

    if _file_exists(ssh, f"{cfg.awi_root}/aa-webui-launcher.jar"):
        return

    # Try local media copy on the AWI host
    if _dir_exists(ssh, cfg.awi_media_path):
        run(ssh, f"cp -r {cfg.awi_media_path}/* {cfg.awi_root}/", check=False)

    if _file_exists(ssh, f"{cfg.awi_root}/aa-webui-launcher.jar"):
        return

    # Fallback: pull from DB host
    _pull_webinterface_from_db_to_awi(ssh, cfg)
def _render_uc4_config_xml(*, trusted_cert_folder: str, system_name: str, jcp_ip_or_cn: str, jcp_port: int) -> str:
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <trace count="10" xml="0"/>
  <connections trustedCertFolder="{trusted_cert_folder}">
    <connection name="AUTOMIC" system="{system_name}">
      <jcp ip="{jcp_ip_or_cn}" port="{jcp_port}"/>
    </connection>
  </connections>
</configuration>
"""

def _push_ae_cert_if_any(ssh: SSHClient, cfg: AWIConfig) -> None:
    if not cfg.ae_cert_local_path:
        return
    local = os.path.expanduser(cfg.ae_cert_local_path)
    tmp_remote = f"/tmp/{cfg.ae_cert_remote_name}"
    put_file(ssh, local, tmp_remote)
    sudo(ssh, f"mkdir -p {cfg.tls_folder} && mv {tmp_remote} {P(cfg.tls_folder) / cfg.ae_cert_remote_name}")

def _write_uc4_config(ssh: SSHClient, cfg: AWIConfig) -> None:
    uc4_xml = _render_uc4_config_xml(
        trusted_cert_folder=cfg.tls_folder,
        system_name=cfg.system_name,
        jcp_ip_or_cn=cfg.jcp_ip_or_cn,
        jcp_port=cfg.jcp_port,
    )
    put_text(ssh, uc4_xml, "/tmp/uc4.config.xml")
    sudo(ssh, f"mkdir -p {P(cfg.awi_root) / 'config'}")
    sudo(ssh, f"mv /tmp/uc4.config.xml {P(cfg.awi_root) / 'config/uc4.config.xml'}")

# --- BEGIN REPLACEMENT: _start_awi ---
def _start_awi(ssh: "SSHClient", cfg: "AWIConfig", port: int = 8080) -> None:
    """
    Start the AWI launcher robustly:
      - stop any previous launcher (non-fatal)
      - ensure AWI dir + osgi-tmp are writable by the runtime user
      - resolve JAVA inside a sudo shell
      - use fully-qualified nohup
      - wait for the chosen port
    """
    # Stop any previous launcher (ignore if none)
    run(ssh, "sudo -n pkill -f 'aa-webui-launcher.jar' || true", check=False)

    log_path = f"{cfg.awi_root}/awi.out"

    # Ensure write access for caches/logs (fixes AccessDenied on osgi-tmp)
    sudo(ssh, f"mkdir -p {cfg.awi_root}/osgi-tmp")
    sudo(ssh, f"chown -R {ssh.user}:{ssh.user} {cfg.awi_root}")
    run(ssh, f"chmod -R u+rwX,g+rwX {cfg.awi_root}", check=False)

    # Resolve JAVA in the same sudo shell and start with full nohup path
    start_cmd = (
        f"sudo -n bash -lc '"
        f"cd {cfg.awi_root} && "
        f"JAVA=\"$(command -v {cfg.java_bin} || command -v java || echo /usr/bin/java)\" && "
        f"/usr/bin/nohup \"$JAVA\" -Dserver.port={port} -jar aa-webui-launcher.jar "
        f"> {log_path} 2>&1 &'"
    )
    run(ssh, start_cmd, check=True)

    # Short delay, then wait for the port to open
    run(ssh, "sleep 1; pgrep -f 'aa-webui-launcher.jar' >/dev/null", check=True)
    _wait_for_local_port(ssh, port, timeout_s=240)
# --- END REPLACEMENT: _start_awi ---
def install_awi(cfg: AWIConfig) -> None:
    """
    Idempotent AWI install/config/start:
      - ensure AWI & TLS directories
      - ensure Java present
      - ensure WebInterface exists on AWI host (copy locally; else scp from DB)
      - push AE cert (optional)
      - render uc4.config.xml with trustedCertFolder + JCP CN/port
      - start launcher and verify health
    """
    with SSHClient(cfg.host, cfg.ssh_user, cfg.key_path) as ssh:
        log.info("== AWI install on %s ==", cfg.host)

        _ensure_dirs(ssh, cfg.awi_root, cfg.tls_folder)
        _ensure_java(ssh, cfg.java_bin)

        # Acquire WebInterface if missing
        _ensure_webinterface_present(ssh, cfg)

        # Optional AE trust chain
        _push_ae_cert_if_any(ssh, cfg)

        # Config
        _write_uc4_config(ssh, cfg)

        # Start + health
        _start_awi(ssh, cfg)

        log.info("AWI is up at %s", cfg.awi_url)
