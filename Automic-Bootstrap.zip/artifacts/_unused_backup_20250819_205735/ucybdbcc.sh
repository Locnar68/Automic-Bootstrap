java -jar ucybdbcc.jar
